package vti.apt_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AptGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(AptGatewayApplication.class, args);
	}

}
