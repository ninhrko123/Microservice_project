package vti.apt_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AptGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
